def greeting():
    print('Welcome to my module')


def author_of_code():
    print('Bill McCulley is the author of this code')