def print_set(s):
    print(s)