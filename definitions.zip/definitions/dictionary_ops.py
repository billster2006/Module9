def print_dict(d):
    for key in d:
        print("key:", key, "Value:", d[key])